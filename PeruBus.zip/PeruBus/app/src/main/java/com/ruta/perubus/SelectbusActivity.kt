package com.ruta.perubus

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class SelectbusActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_selectbus)
    }
}